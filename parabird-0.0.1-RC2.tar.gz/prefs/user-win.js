user_pref("extensions.enigmail.agentPath", "./../../apps/linux/gpg4usb/bin/gpg.exe");
