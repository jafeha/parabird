user_pref("extensions.enigmail.agentPath", "./../../apps/mac/gpg/gpg");
